package DZT::Sample;
# ABSTRACT: a sample module
our $VERSION = '0.001'; # comment

package DZT::Inner;
our $VERSION = '0.001';

1;                      # last line
