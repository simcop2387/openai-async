package DZT::DQuote;
# ABSTRACT: a sample module
our $VERSION = "0.001"; # comment
1;                      # last line
