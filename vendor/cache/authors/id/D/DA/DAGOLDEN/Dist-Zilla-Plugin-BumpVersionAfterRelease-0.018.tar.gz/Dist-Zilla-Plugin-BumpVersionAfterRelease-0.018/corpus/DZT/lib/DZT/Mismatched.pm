package DZT::Mismatched;
# ABSTRACT: a sample module with mismatched $VERSIONs
our $VERSION = '0.003'; # first VERSION

package DZT::Inner;
our $VERSION = '0.004'; # second VERSION

1;                      # last line
