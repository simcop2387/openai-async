package Foo;
use strict;
use warnings;
# ABSTRACT: Foo this thing

sub foo { 123 }

1;

=head1 DESCRIPTION

Foo the foo.

=cut
