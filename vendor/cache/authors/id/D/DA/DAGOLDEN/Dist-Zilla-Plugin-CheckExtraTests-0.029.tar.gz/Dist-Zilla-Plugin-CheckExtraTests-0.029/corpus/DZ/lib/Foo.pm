package Foo;
use strict;
use warnings;
# ABSTRACT: Foo this thing

1;

=head1 DESCRIPTION

Foo the foo.

=cut
