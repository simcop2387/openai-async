#!/usr/bin/perl

if ( 1 ) {
	print "Hello World!\n";
}

1;

