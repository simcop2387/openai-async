package Foo;
use strict;
use warnings;
# ABSTRACT: Foo this thing

use File::Spec;
use File::Basename;

1;

=head1 DESCRIPTION

Foo the foo.

=cut
