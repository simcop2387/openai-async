foo
#line 57 Thingy.pm
bar
