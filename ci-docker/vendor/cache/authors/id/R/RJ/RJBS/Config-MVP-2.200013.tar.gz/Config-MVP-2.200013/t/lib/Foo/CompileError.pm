use strict;
package Foo::CompileError;
$x = 10;
1;
