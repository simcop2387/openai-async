package Foo::Boo1;
1;
