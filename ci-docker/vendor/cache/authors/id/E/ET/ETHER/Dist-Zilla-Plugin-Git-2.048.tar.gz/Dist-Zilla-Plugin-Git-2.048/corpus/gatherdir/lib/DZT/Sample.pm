package
  DZT::Sample;
1;
